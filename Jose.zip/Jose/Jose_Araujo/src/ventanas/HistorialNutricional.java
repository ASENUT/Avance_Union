package ventanas;

import java.awt.HeadlessException;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class HistorialNutricional extends javax.swing.JFrame {

    static String nomtrata;
    static String cedulacorporal;
    public static String cedulantri = "";

    public HistorialNutricional() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JLabel();
        btnMedidasCorporales = new javax.swing.JButton();
        btnRegistroPeso = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Apellido", "Tratamiento", "Fecha", "Atendido"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 710, 320));

        jLabel3.setText("Cedula: ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, -1, -1));

        txtCedula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCedulaFocusLost(evt);
            }
        });
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 120, 20));

        btnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Lupa.jpg"))); // NOI18N
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 30, 30));

        btnMedidasCorporales.setText("Medidas Corporales");
        btnMedidasCorporales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMedidasCorporalesMouseClicked(evt);
            }
        });
        getContentPane().add(btnMedidasCorporales, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, -1, -1));

        btnRegistroPeso.setText("Registro Peso");
        btnRegistroPeso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegistroPesoMouseClicked(evt);
            }
        });
        getContentPane().add(btnRegistroPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 20, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel1.setName("ficha"); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 400));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jMenu3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        jMenu3.setText("Imprimir");
        jMenuBar1.add(jMenu3);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Update.png"))); // NOI18N
        jMenu1.setText("Actualizar");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu2.setText("Regresar");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        TratamientoNutricional tn = new TratamientoNutricional();
        tn.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // CARGAMOS TABLA
        btnMedidasCorporales.setVisible(false);
        btnRegistroPeso.setVisible(false);
        txtCedula.setText(cedulantri);
        boolean hay = false;
        if (cedulantri == "") {
            hay = false;
        } else {
            hay = true;
        }
        
        if (hay != true) {
            btnMedidasCorporales.setVisible(false);
            btnRegistroPeso.setVisible(false);
        } else {
            btnMedidasCorporales.setVisible(true);
            btnRegistroPeso.setVisible(true);
        }

        
        System.out.println(cedulantri);

        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;

        try {
            dtm.addColumn("Nombre");
            dtm.addColumn("Apellido");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Fecha");
            dtm.addColumn("Atendido");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, PT.FECHA_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT ,USUARIO U WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND TT.COD_TRATA_FACIAL = 1 ");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked
        // TODO add your handling code here:
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        cedulantri = txtCedula.getText();
        String cedula = "'" + txtCedula.getText() + "'";

        try {
            dtm.addColumn("Nombre");
            dtm.addColumn("Apellido");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Fecha");
            dtm.addColumn("Atendido");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, PT.FECHA_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT ,USUARIO U WHERE P.CEDULA "
                    + "= PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND TT.COD_TRATA_FACIAL = 1 "
                    + "AND PT.CEDULA = " + cedula);
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        /*select MD.FECHA_MEDICION, TT.NOM_TRATA, MD.BUSTO, MD.CADERAS, MD.CINTURA, MD.ENTREPIERNA_DER, 
         MD.ENTREPIERNA_IZ, MD.ESTOMAGO, MD.MUSLO_DER, MD.MUSLO_IZ from MEDIDAS_CORPORALES MD, 
         PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT where MD.CEDULA = '0802502948' AND MD.CEDULA = 
         PT.CEDULA AND MD.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.NOM_TRATA = 'NUTRICIONAL 1';*/

        int filaseleccionada;

        try {
            filaseleccionada = jTable1.getSelectedRow();
            if (filaseleccionada == -1) {
                JOptionPane.showMessageDialog(null, "No se ha seleccionado ninguna fila");
            } else {
                DefaultTableModel modelo_tabla = (DefaultTableModel) jTable1.getModel();
                nomtrata = "'" + (String) (modelo_tabla.getValueAt(filaseleccionada, 2)) + "'";
                System.out.println(nomtrata);
            }
        } catch (HeadlessException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex + "\nInténtelo nuevamente", " .::Error En la Operacion::.", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnRegistroPesoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegistroPesoMouseClicked
        // TODO add your handling code here:
        RegistroTratamientoNutri to = new RegistroTratamientoNutri();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegistroPesoMouseClicked

    private void btnMedidasCorporalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMedidasCorporalesMouseClicked
        // TODO add your handling code here:
        RegistroMedidasCorporales to = new RegistroMedidasCorporales();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnMedidasCorporalesMouseClicked

    private void txtCedulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCedulaFocusLost
        // TODO add your handling code here:
        ResultSet rs;
        int cont = 0;
        boolean hay = false;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from PACIENTE WHERE CEDULA = '" + txtCedula.getText() + "'");
            while (rs.next()) {
                cont++;
                hay = true;
            }
            if (cont == 0) {
                JOptionPane.showMessageDialog(null, "El paciente no existe");
                hay = false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }

        cedulacorporal = txtCedula.getText();
        if (hay != true) {
            btnMedidasCorporales.setVisible(false);
            btnRegistroPeso.setVisible(false);
        } else {
            btnMedidasCorporales.setVisible(true);
            btnRegistroPeso.setVisible(true);
        }
    }//GEN-LAST:event_txtCedulaFocusLost

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        // TODO add your handling code here:
        btnMedidasCorporales.setVisible(false);
        btnRegistroPeso.setVisible(false);
        txtCedula.setText("");

        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;

        try {
            dtm.addColumn("Nombre");
            dtm.addColumn("Apellido");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Fecha");
            dtm.addColumn("Atendido");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, PT.FECHA_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT ,USUARIO U WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND TT.COD_TRATA_FACIAL = 1 ");
            while (rs.next()) {
                dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jMenu1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HistorialNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HistorialNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HistorialNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HistorialNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HistorialNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnBuscar;
    private javax.swing.JButton btnMedidasCorporales;
    private javax.swing.JButton btnRegistroPeso;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtCedula;
    // End of variables declaration//GEN-END:variables
}
